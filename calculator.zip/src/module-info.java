module MATH421_Creativity {
	requires java.desktop;
}