package Poly_factoring;

import java.util.ArrayList;
//import java.util.Arrays;

//import java.util.Scanner;
public class Tester {

	public static void main(String[] args) {
		Calulator win = new Calulator();
		win.run();
		
		//int charac= 41;
		//int[] f = {1, 0, -4}, g = {1,-2};
		//ArrayList<int[]> out = Polynomial.polyDivide(f, g, charac);
		//int[] r = Polynomial.findGCD(f, g, charac);
		
		//System.out.println(Polynomial.displayPoly(out.get(0)));
	}
	
}
